module Voca {
}